from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='market-home'),
    path('fashion/', views.fashion, name='market-fashion'),
    path('appliances/', views.appliances, name='market-appliances'),
    path('gadgets/', views.gadgets, name='market-gadgets'),
]